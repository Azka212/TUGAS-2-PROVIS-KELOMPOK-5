package com.example.flutter_tugas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
